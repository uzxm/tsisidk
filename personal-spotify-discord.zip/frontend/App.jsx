import { useState, useRef } from "react";

export default function App() {
  const [songs, setSongs] = useState([]);
  const [current, setCurrent] = useState(null);
  const audioRef = useRef(null);

  const handleFiles = (e) => {
    const files = Array.from(e.target.files);
    const newSongs = files.map((file) => ({
      name: file.name,
      url: URL.createObjectURL(file),
      file,
    }));
    setSongs((prev) => [...prev, ...newSongs]);
  };

  const playSong = (song) => {
    setCurrent(song);
    fetch("http://localhost:3020/update", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ track: song.name }),
    });
    setTimeout(() => {
      audioRef.current?.play();
    }, 100);
  };

  return (
    <div className="p-6 space-y-6 max-w-2xl mx-auto">
      <h1 className="text-3xl font-bold">🎧 My Personal Spotify</h1>
      <input type="file" multiple accept="audio/*" onChange={handleFiles} />
      {songs.length > 0 && (
        <div className="grid gap-4">
          {songs.map((song, i) => (
            <div key={i} onClick={() => playSong(song)} className="cursor-pointer bg-gray-200 p-2 rounded">
              {song.name}
            </div>
          ))}
        </div>
      )}
      {current && (
        <div className="fixed bottom-0 left-0 right-0 bg-gray-900 text-white p-4">
          <div className="flex items-center justify-between">
            <span>Now Playing: {current.name}</span>
            <audio ref={audioRef} controls src={current.url} className="w-64" />
          </div>
        </div>
      )}
    </div>
  );
}